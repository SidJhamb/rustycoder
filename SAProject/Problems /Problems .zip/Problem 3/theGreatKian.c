#include <stdio.h>
 
int main() {
    long i, n;
    unsigned long long a, b, c, t;
    a = b = c = 0;
    
    scanf("%ld", &n);
    
    for (i = 0; i < n; i++) {
    	if (i % 3 == 0) {
    		scanf("%llu", &t);
    		a += t;
    	}
    	else if (i % 3 == 1) {
    		scanf("%llu", &t);
    		b += t;
    	}
    	else {
    		scanf("%llu", &t);
    		c += t;
    	}
    }
    
    printf("%llu %llu %llu", a, b, c);
    
    return 0;
}